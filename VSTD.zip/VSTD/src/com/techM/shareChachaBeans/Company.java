package com.techM.shareChachaBeans;

import java.sql.Timestamp;

import oracle.sql.TIMESTAMP;

public class Company {
	private String companyID;
	private String companyName;
	private int totalShares;
	private double currentPrice;
	private int availableShares;
	private String seller;
	private Timestamp dateTime;
	
	
	

	public Company(String companyID, String companyName, int totalShares,
			double currentPrice, int availableShares, String seller
			) {
		super();
		this.companyID = companyID;
		this.companyName = companyName;
		this.totalShares = totalShares;
		this.currentPrice = currentPrice;
		this.availableShares = availableShares;
		this.seller = seller;
		
	}

	public Company() {
		// TODO Auto-generated constructor stub
	}

	public String getCompanyID() {
		return companyID;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getTotalShares() {
		return totalShares;
	}

	public void setTotalShares(int totalShares) {
		this.totalShares = totalShares;
	}

	public double getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}

	public int getAvailableShares() {
		return availableShares;
	}

	public void setAvailableShares(int availableShares) {
		this.availableShares = availableShares;
	}

	public String getSeller() {
		return seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	@Override
	public String toString() {
		return "Company [companyID=" + companyID + ", companyName="
				+ companyName + ", totalShares=" + totalShares
				+ ", currentPrice=" + currentPrice + ", availableShares="
				+ availableShares + ", seller=" + seller + ", dateTime="
				+ dateTime + "]";
	}
	
	

}
