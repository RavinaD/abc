package com.techM.shareChachaBeans;

import java.sql.Timestamp;

public class Transaction {
	private String transactionID;
	private Timestamp dateTime;
	private String sellerID;
	private String buyerID;
	private String companyID;
	private String companyName;
	private int shares;
	private Double txnPrice;
	private Double currentPrice;

	public String getTransactionID() {
		return transactionID;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public String getSellerID() {
		return sellerID;
	}

	public String getBuyerID() {
		return buyerID;
	}

	public String getCompanyID() {
		return companyID;
	}

	public String getCompanyName() {
		return companyName;
	}

	public int getShares() {
		return shares;
	}

	public Double getTxnPrice() {
		return txnPrice;
	}

	public Double getCurrentPrice() {
		return currentPrice;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public void setSellerID(String sellerID) {
		this.sellerID = sellerID;
	}

	public void setBuyerID(String buyerID) {
		this.buyerID = buyerID;
	}

	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public void setShares(int shares) {
		this.shares = shares;
	}

	public void setTxnPrice(Double txnPrice) {
		this.txnPrice = txnPrice;
	}

	public void setCurrentPrice(Double currentPrice) {
		this.currentPrice = currentPrice;
	}

}
