package com.techM.shareChacha.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Statement;
import com.techM.shareChachaBeans.Company;
import com.techM.shareChachaBeans.User;
import com.techM.shareChachaDB.UserDB;
public class AddStocksServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	public AddStocksServlet() 
	{
		super();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		super.doGet(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		int i = 0;
		try 
		{
			UserDB uDB = new UserDB();
			Connection c= uDB.getConnection();
			String query="select companyid from companytable";

			ResultSet rs=c.createStatement().executeQuery(query);
			String cd=null;
			while(rs.next())
			{
				cd=rs.getString(1);
			}		
			
			int compID=Integer.parseInt(cd)+100;
			
			Company comp = new Company();
			
			comp.setCompanyName(request.getParameter("companyName"));
			comp.setTotalShares(Integer.parseInt(request.getParameter("totalShares")));
			comp.setCurrentPrice(Double.parseDouble(request.getParameter("currentPrice")));
			comp.setCompanyID(String.valueOf(compID));					
			comp.setAvailableShares(comp.getTotalShares());
			comp.setSeller(request.getParameter("Seller"));			

			User u = (User) session.getAttribute( "userObj");

			out.print(u.getUserName());

			i = uDB.addStock(comp, u.getUserID());

			if( i == 2 ) 
			{
				session.setAttribute("row", "1 company added");

				RequestDispatcher rd = request.getRequestDispatcher("/addStocks.jsp");
				rd.forward(request, response);
			}
			else 
			{
				throw new Exception();
			}

		} catch (SQLException e) 
		{ 			
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			session.setAttribute("status", " Company could not be added. Please try again..");

			RequestDispatcher rd = request.getRequestDispatcher("/addStocks.jsp");
			rd.forward(request, response);
		}

	}
}


