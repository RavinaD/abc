package com.techM.shareChacha.controller;



import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techM.shareChachaBeans.Company;
import com.techM.shareChachaDB.UserDB;
public class PurchasePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public PurchasePageServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession(false);
		
		try {
		ArrayList<Company> alist=new ArrayList<Company>();
		
		
		
		UserDB uDB = new UserDB();	
		alist = uDB.purchaseStocks( );
		
		if( alist != null)
	    {
			session.setAttribute("purchaseList",alist);
	    	RequestDispatcher rd=request.getRequestDispatcher("purchase.jsp");
	    	rd.forward(request,response);
	    }
		else {
			throw new Exception();
		}
		} catch (Exception e) {	
	    	session.setAttribute("status","error");
	    	RequestDispatcher rd=request.getRequestDispatcher("user.jsp");
	    }
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession(false);
		
		try {
		ArrayList<Company> alist=new ArrayList<Company>();
		
		
		
		UserDB uDB = new UserDB();	
		alist = uDB.purchaseStocks( );
		
		if( alist != null)
	    {
			session.setAttribute("purchaseList",alist);
	    	RequestDispatcher rd=request.getRequestDispatcher("/purchase.jsp");
	    	rd.forward(request,response);
	    }
		else {
			throw new Exception();
		}
		} catch (Exception e) {	
	    	session.setAttribute("status","error");
	    	RequestDispatcher rd=request.getRequestDispatcher("/user.jsp");
	    }
	}
*/
}
}
